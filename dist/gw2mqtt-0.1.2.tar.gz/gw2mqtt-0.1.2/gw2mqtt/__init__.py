__version__ = "0.1.2"

__all__ = [ 'goodwe_inverter' ]
