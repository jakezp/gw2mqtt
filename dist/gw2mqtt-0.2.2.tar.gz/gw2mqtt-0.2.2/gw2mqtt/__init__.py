__version__ = "0.2.2"

__all__ = [ 'goodwe_inverter' ]
